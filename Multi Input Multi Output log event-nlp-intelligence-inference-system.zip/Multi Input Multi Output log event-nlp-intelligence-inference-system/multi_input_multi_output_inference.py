#!/usr/bin/env python
# coding: utf-8

# In[3]:


# 1️⃣ Imports
import os  # 1
import json  # 2
import pickle  # 3
import numpy as np  # 4
import pandas as pd  # 5
import tensorflow as tf  # 6
from keras.layers import TFSMLayer  # 7
from tensorflow.keras.preprocessing.sequence import pad_sequences # 8
from pathlib import Path #9

# 2️⃣ Path Setup
model_path = "/kaggle/input/intelligence-model/log_intelligence_model.h5"  # 9
vec_path = "/kaggle/input/intelligence-model/text_vectorization"  # 10
enc_path = "/kaggle/input/intelligence-model/label_encoders.pkl"  # 11
config_path = "/kaggle/input/intelligence-model/config.json"  # 12
maxlen_path = "/kaggle/input/intelligence-model/max_len.pkl"  # 13
data_path = "/kaggle/input/new-unknown-data/New Unknown Data - New Unknown Data.csv.csv"  # 14

# 3️⃣ Load Model and Components
model = tf.keras.models.load_model(model_path, compile=False)  # 15
text_vec = TFSMLayer(vec_path, call_endpoint="serve")  # 16
with open(enc_path, "rb") as f:  # 17
    encoders = pickle.load(f)  # 18
with open(config_path, "r") as f:  # 19
    config = json.load(f)  # 20
with open(maxlen_path, "rb") as f:  # 21
    max_len = pickle.load(f)  # 22

level_enc = encoders["level"]  # 23
source_enc = encoders["source"]  # 24
taskcat_enc = encoders["taskcat"]  # 25

# 4️⃣ Load & Preprocess Data
df = pd.read_csv(data_path)  # 26
df.columns = df.columns.str.strip().str.lower().str.replace(" ", "_")  # 27
df = df.rename(columns={"messages": "message"})  # 28

required_cols = ["message", "level", "source", "task_category", "event_id", "date_and_time"]  # 29
missing_cols = [col for col in required_cols if col not in df.columns]  # 30
if missing_cols:  # 31
    raise KeyError(f"Missing required columns in input data: {missing_cols}")  # 32

df = df.dropna(subset=required_cols).reset_index(drop=True)  # 33

# 5️⃣ Feature Engineering
df["event_id"] = pd.to_numeric(df["event_id"], errors="coerce").fillna(0)  # 34
df["event_id"] = np.log1p(df["event_id"])  # 35
df["date_and_time"] = pd.to_datetime(df["date_and_time"], errors="coerce")  # 36
df["hour"] = df["date_and_time"].dt.hour.fillna(0) / 23.0  # 37
df["weekday"] = df["date_and_time"].dt.dayofweek.fillna(0) / 6.0  # 38

# 6️⃣ Categorical Encoding (ignore unseen categories)
df["source"] = df["source"].astype(str).str.strip().str.lower()  # 39
df["task_category"] = df["task_category"].astype(str).str.strip().str.lower()  # 40
df["level"] = df["level"].astype(str).str.strip().str.capitalize()  # 41

df = df[df["source"].isin(source_enc.classes_)]  # 42
df = df[df["task_category"].isin(taskcat_enc.classes_)]  # 43
df = df[df["level"].isin(level_enc.classes_)]  # 44
df = df.reset_index(drop=True)  # 45

if len(df) == 0:  # 46
    raise ValueError("⚠️ No valid data remains after filtering.")  # 47

# 7️⃣ Vectorize Inputs
msg_input = text_vec(tf.convert_to_tensor(df["message"].values.reshape(-1, 1)))  # 48
msg_input = pad_sequences(msg_input.numpy(), maxlen=max_len, padding="post")  # 49

source_input = source_enc.transform(df["source"])  # 50
taskcat_input = taskcat_enc.transform(df["task_category"])  # 51
eventid_input = df["event_id"].astype(np.float32).values  # 52
hour_input = df["hour"].astype(np.float32).values  # 53
weekday_input = df["weekday"].astype(np.float32).values  # 54

# 8️⃣ Run Inference
print("🚀 Running inference...")  # 55
preds = model.predict([  # 56
    msg_input,  # 57
    source_input,  # 58
    taskcat_input,  # 59
    eventid_input,  # 60
    hour_input,  # 61
    weekday_input  # 62
], verbose=0)  # 63

# 9️⃣ Decode Predictions
df["Predicted_Level"] = level_enc.inverse_transform(np.argmax(preds[0], axis=1))  # 64
df["Predicted_EventID"] = np.round(preds[1].flatten().astype("float32")).astype("int")  # 65
df["Predicted_TaskCat"] = taskcat_enc.inverse_transform(np.argmax(preds[2], axis=1))  # 66
df["Predicted_Source"] = source_enc.inverse_transform(np.argmax(preds[3], axis=1))  # 67
df["Confidence_Level"] = np.max(preds[0], axis=1).round(3)  # 68

# 🔟 Summarize
summary = df["Predicted_Level"].value_counts().reset_index()  # 69
summary.columns = ["Predicted_Level", "count"]  # 70
print("\n📊 Summary by Predicted Level:\n", summary)  # 71

warnings = df[df["Predicted_Level"].isin(["Error", "Warning"])]  # 72
print("\n🚨 Sample Critical Logs (Error/Warning):")  # 73
print(warnings[["message", "Predicted_Level", "Confidence_Level"]].head())  # 74

# 🔁 Save Output
df.to_csv("detailed_inference_results.csv", index=False)  # 75
print("\n📁 Full results saved to 'detailed_inference_results.csv'")  # 76 

# 📦 Imports
import pandas as pd
import matplotlib.pyplot as plt

# 📂 Load results
df = pd.read_csv("detailed_inference_results.csv")

# 📊 Summary Chart
summary = df["Predicted_Level"].value_counts().reset_index()
summary.columns = ["Predicted_Level", "Count"]

plt.figure(figsize=(8, 5))
plt.bar(summary["Predicted_Level"], summary["Count"])
plt.title("Log Event Distribution by Predicted Level")
plt.xlabel("Predicted Level")
plt.ylabel("Number of Events")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("log_level_distribution.png")
plt.show()

# 🧠 NLP-Based Event Summary
print("\n📌 NLP Insights:")
for level in ["Error", "Warning", "Information", "Verbose"]:
    logs = df[df["Predicted_Level"] == level]["message"]
    if not logs.empty:
        sample = logs.sample(1).values[0][:250]
        print(f"🔹 {level}: Example log — \"{sample}...\"") 

# 11️⃣ Add Severity Score
severity_map = {"Error": 1.0, "Warning": 0.7, "Information": 0.4, "Verbose": 0.2}
df["Severity_Score"] = df["Predicted_Level"].map(severity_map)

# 1️⃣2️⃣ Summarized Message Column (first sentence or 20 words)
def summarize_message(msg):
    if not isinstance(msg, str):
        return ""
    summary = msg.split(".")[0]
    if len(summary.split()) > 20:
        return " ".join(summary.split()[:20]) + "..."
    return summary.strip() + "..."

df["Message_Summary"] = df["message"].apply(summarize_message)

# 1️⃣3️⃣ Level Distribution %
level_counts = df["Predicted_Level"].value_counts(normalize=True) * 100
df["Level_Percentage"] = df["Predicted_Level"].map(lambda x: round(level_counts[x], 2))

# 1️⃣4️⃣ Simplified Date Column
df["Short_Date"] = pd.to_datetime(df["date_and_time"], errors="coerce").dt.date

# 1️⃣5️⃣ Add Dashboard Flag for Critical Logs
df["Is_Critical"] = df["Predicted_Level"].isin(["Error", "Warning"]).astype(int)

# 1️⃣6️⃣ Save Enhanced CSV
df.to_csv("enhanced_inference_results.csv", index=False)
print("✅ Enhanced file saved as 'enhanced_inference_results.csv'")

# 1️⃣7️⃣ Optional: Save Pie Chart of Level Distribution
import matplotlib.pyplot as plt

plt.figure(figsize=(6, 6))
plt.pie(level_counts, labels=level_counts.index, autopct="%1.1f%%", startangle=90)
plt.title("Log Level Distribution")
plt.tight_layout()
plt.savefig("log_level_pie.png")
plt.show()
print("📊 Pie chart saved as 'log_level_pie.png'") 










